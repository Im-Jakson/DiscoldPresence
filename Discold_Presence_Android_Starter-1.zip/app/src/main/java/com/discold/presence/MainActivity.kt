package com.discold.presence

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.pm.PackageManager
import android.app.usage.UsageStatsManager
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 16, 25)
    private val panel = Color.rgb(25, 30, 44)
    private val accent = Color.rgb(116, 139, 255)
    private var selectedPackage: String? = null
    private var selectedLabel: String = "No game selected"
    private var sessionStart = 0L
    private lateinit var status: TextView
    private lateinit var gameText: TextView
    private lateinit var timerText: TextView
    private lateinit var presenceText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        updatePermissionStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 20)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = TextView(this).apply {
            text = "◈  DIS COLD\n     PRESENCE"
            textSize = 25f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }
        content.addView(brand)
        content.addView(label("YOUR GAMES, YOUR PRESENCE", 12, accent))
        content.addView(space(22))
        content.addView(cardTitle("Connection"))
        status = label("Discord integration: not connected", 14, Color.LTGRAY)
        content.addView(status)
        content.addView(label("This starter does not ask for a Discord user token. Account self-bot tokens are unsafe and against Discord rules.", 12, Color.rgb(255,190,120)))
        content.addView(space(18))
        content.addView(cardTitle("Game selector"))
        gameText = label(selectedLabel, 16, Color.WHITE)
        content.addView(gameText)
        val choose = button("Select installed app") { showApps() }
        content.addView(choose)
        val permission = button("Grant usage access") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        content.addView(permission)
        content.addView(space(18))
        content.addView(cardTitle("Presence preview"))
        timerText = label("Session: 00:00:00", 14, Color.LTGRAY)
        content.addView(timerText)
        presenceText = label("Playing\nSelect a game to preview its activity.", 16, Color.WHITE)
        content.addView(presenceText)
        content.addView(button("Check active app") { checkActiveApp() })
        content.addView(button("Start local session") {
            if (selectedPackage == null) toast("Select a game first")
            else { sessionStart = System.currentTimeMillis(); timerText.text = "Session started"; toast("Local session started") }
        })
        content.addView(button("Stop session") {
            sessionStart = 0L; timerText.text = "Session: 00:00:00"; toast("Session stopped")
        })
        content.addView(space(18))
        content.addView(cardTitle("What's included"))
        content.addView(label("• Dark Android starter UI\n• Installed-app selector\n• Usage access status\n• Foreground app check\n• Local session timer preview\n• Safe Discord integration boundary", 13, Color.LTGRAY))
        content.addView(space(18))
        content.addView(label("Version 0.1.0 • Android 8.0+", 11, Color.GRAY))
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun cardTitle(s: String): TextView = label(s, 18, Color.WHITE).apply {
        typeface = Typeface.DEFAULT_BOLD
        setPadding(14, 13, 14, 8)
        background = rounded(panel, 16)
    }
    private fun label(s: String, size: Int, color: Int) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        setPadding(4, 9, 4, 9)
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setTextColor(Color.WHITE)
        background = rounded(accent, 14)
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 7; bottomMargin = 5 }
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }
    private fun updatePermissionStatus() {
        status.text = if (hasUsageAccess()) "Usage access: enabled • Discord: not connected"
                      else "Usage access: not granted • Discord: not connected"
    }
    private fun showApps() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase(Locale.getDefault()) }
        val names = apps.map { pm.getApplicationLabel(it).toString() }
        if (apps.isEmpty()) { toast("No launchable apps found"); return }
        AlertDialog.Builder(this)
            .setTitle("Choose an app")
            .setItems(names.toTypedArray()) { _, which ->
                val info = apps[which]
                selectedPackage = info.packageName
                selectedLabel = pm.getApplicationLabel(info).toString()
                gameText.text = "$selectedLabel\n${info.packageName}"
                presenceText.text = "Playing $selectedLabel\nWaiting for local session."
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    private fun checkActiveApp() {
        if (!hasUsageAccess()) {
            toast("Grant Usage Access first")
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usm.queryEvents(end - 60_000, end)
        val event = android.app.usage.UsageEvents.Event()
        var latest: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND ||
                event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) {
                latest = event.packageName
            }
        }
        val app = latest?.let {
            try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it, 0)).toString() }
            catch (_: Exception) { it }
        } ?: "Unknown"
        toast("Most recent foreground app: $app")
    }
    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updatePermissionStatus()
        if (sessionStart > 0L && ::timerText.isInitialized) {
            val elapsed = (System.currentTimeMillis() - sessionStart) / 1000
            val h = elapsed / 3600; val m = (elapsed % 3600) / 60; val s = elapsed % 60
            timerText.text = String.format(Locale.US, "Session: %02d:%02d:%02d", h, m, s)
        }
    }
}
