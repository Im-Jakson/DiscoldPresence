package com.discold.presence

/**
 * Integration boundary only.
 *
 * Never accept or store a Discord personal user token here.
 * Implement only with a Discord-supported SDK/RPC flow that is valid for
 * the target Android use case and application registration.
 */
interface DiscordPresenceAdapter {
    fun connect()
    fun publish(details: String, state: String)
    fun clear()
    fun disconnect()
}
